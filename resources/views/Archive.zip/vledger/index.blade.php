@extends('layouts.admin')


@section('page-title')
    {{__('Agent Ledger')}}

@endsection

@push('script-page')
    
@endpush


@php
    $agents = \App\Models\Agent::pluck('agent_name', 'id');
    $ledgers = \App\Models\Ledger::get();
@endphp




@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{__('Dashboard')}}</a></li>
    <li class="breadcrumb-item active">{{__('Agent Ledger')}}</li>

@endsection

@section('action-btn')
    <div class="float-end">
        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#createAgent">
        <i class="ti ti-plus"></i>
        </button>
    </div>
@endsection

@section('modal')

@endsection

@section('content')

<div class="modal fade" id="createAgent" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <form method="post" action="{{ route('vendors.store') }}">
  @csrf
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Vendor</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="row">
                <div class="form-group">
                    <label for="vendor_name" class="form-label">Vendor Name</label>
                    <input type="text" name="vendor_name" class="form-control" placeholder="Vendor Name" required>
                    <label for="company_details" class="form-label">Company Details</label>
                    <textarea name="company_details" class="form-control" placeholder="Company Details" required></textarea>
                </div>
                <div class="form-group">
                    <label for="visa_type" class="form-label">Visa Type</label>
                    <select name="visa_type" class="form-control" required>
                        <option value="WV">Work Permit Visa</option>
                        <option value="BV">Business Visa</option>
                        <option value="SV">Student Visa</option>
                        <option value="TV">Tourist Visa</option>
                        <option value="OV">Others</option>
                    </select>

                </div>

                
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Add Vendor"></input>
      </div>
    </div>
    </form>
  </div>
</div>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        
                    </div>
                    <div class="table-responsive">
                        <table class="table datatable">
                            <thead>
                            <tr>
                                <th>{{__('Date')}}</th>
                                <th>{{__('Paid For')}}</th>
                                <th>{{__('Unit Price')}}</th>
                                <th>{{__('Number of Unit')}}</th>
                                <th>{{__('Payment Mode')}}</th>
                                <th>{{__('Amount')}}</th>
                                <th>{{__('Advance')}}</th>
                                <th>{{__('Due')}}</th>
                                <th>{{__('Refund')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach ($ledgers as $ledger)
                                <tr>
                                    <td>{{$ledger->date}}</td>
                                    <td>{{$ledger->paid_for}}</td>
                                    <td>{{$ledger->unit_price}}</td>
                                    <td>{{$ledger->number_of_unit}}</td>
                                    <td>{{$ledger->payment_mode}}</td>
                                    <td>{{$ledger->amount}}</td>
                                    <td>{{$ledger->advance}}</td>
                                    <td>{{$ledger->due}}</td>
                                    <td>{{$ledger->refund}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

